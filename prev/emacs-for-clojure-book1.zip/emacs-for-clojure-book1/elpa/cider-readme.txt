Provides a Clojure IDE and REPL for Emacs, built on top of nREPL.

Installation:

Available as a package in marmalade-repo.org and melpa.milkbox.net.

(add-to-list 'package-archives
             '("marmalade" . "http://marmalade-repo.org/packages/"))

or

(add-to-list 'package-archives
             '("melpa" . "http://melpa.milkbox.net/packages/") t)

M-x package-install cider
